MBK / NAIJAHUB WEBSITE — FRONT-END STARTER

WHAT THIS IS
A responsive static website prototype with:
- Overview dashboard and demo statistics
- Service directory and search
- Demo request form
- Request history search and status filtering
- Account/API connection information page
- Responsive mobile navigation

IMPORTANT LIMITATIONS
This is the front-end stage only. It does NOT have real authentication, a database, payments, live identity verification, or a Tech Hub API connection. Request examples and new demo requests are stored only in the current browser session's JavaScript memory and disappear when the page is refreshed. Do not enter real NIN/BVN data or API secrets.

HOW TO TEST ON ANDROID
Option A — simplest:
1. Extract the ZIP file using your file manager.
2. Open index.html in a browser if your device allows local HTML files.
3. If local opening is restricted, upload the three website files (index.html, styles.css, app.js) to a static hosting service such as GitHub Pages or Netlify.

Option B — AIDE:
AIDE is primarily for Android apps, not the easiest way to publish a website. You can edit these files in a code editor, then upload them to a static host.

FREE HOSTING NEXT
A static host can publish this front end for free. To add secure login and live API requests, we will need a backend service and database. Free tiers and provider requirements can change.

NEXT DEVELOPMENT STAGES
1. Publish the static front end.
2. Choose backend hosting and database.
3. Implement secure registration/login and role-based permissions.
4. Confirm current Tech Hub API docs, endpoints, authentication, allowed services, and test environment.
5. Build server-side API integration with secrets stored in environment variables.
6. Test error handling, request history, audit logs, and data protection.
