const services = [
  {name:"NIN Adult Enrollment",desc:"Adult enrollment workflow for approved provider services.",icon:"♙",key:"adult"},
  {name:"NIN Child Enrollment",desc:"Child enrollment workflow where provider access is authorized.",icon:"♧",key:"child"},
  {name:"NIN Personalization",desc:"Track a personalization request by tracking ID.",icon:"▤",key:"personalization"},
  {name:"NIN Modification",desc:"Name or date-of-birth modification request workflow.",icon:"✎",key:"modification"},
  {name:"NIN Validation",desc:"Submit an authorized NIN validation request.",icon:"✓",key:"validation"},
  {name:"IPE Clearance",desc:"Track IPE clearance only if the provider currently supports it.",icon:"◈",key:"ipe"},
  {name:"NIN Slip Printing",desc:"Slip printing request workflow, subject to provider availability.",icon:"▧",key:"slip"},
  {name:"NIN Retrieval / Update",desc:"Retrieval or phone update workflow, subject to authorization.",icon:"↻",key:"retrieval"}
];
let requests = [
  {id:"MBK-260010",service:"NIN Validation",ref:"•••• 4821",date:"10 Oct 2026",status:"Completed"},
  {id:"MBK-260009",service:"NIN Personalization",ref:"TRK••••91",date:"09 Oct 2026",status:"Pending"},
  {id:"MBK-260008",service:"NIN Modification",ref:"•••• 1174",date:"08 Oct 2026",status:"Pending"},
  {id:"MBK-260007",service:"IPE Clearance",ref:"IPE••••06",date:"07 Oct 2026",status:"Failed"},
  {id:"MBK-260006",service:"NIN Adult Enrollment",ref:"•••• 9205",date:"06 Oct 2026",status:"Completed"}
];
const $ = id => document.getElementById(id);
const safe = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function card(s){return `<article class="service-card"><div class="service-symbol">${s.icon}</div><h3>${safe(s.name)}</h3><p>${safe(s.desc)}</p><button data-service="${safe(s.key)}">Open service →</button></article>`}
function status(s){return `<span class="status ${s.toLowerCase()}">${safe(s)}</span>`}
function renderServices(){ $('quickServices').innerHTML=services.slice(0,4).map(card).join(''); const q=($('serviceSearch')?.value||'').toLowerCase();const list=services.filter(s=>(s.name+' '+s.desc).toLowerCase().includes(q));$('allServices').innerHTML=list.length?list.map(card).join(''):'<div class="empty-row">No matching services found.</div>';$('serviceCount').textContent=`${list.length} service${list.length===1?'':'s'}`}
function row(r,full=false){return `<tr><td><span class="request-id">${safe(r.id)}</span></td><td>${safe(r.service)}</td>${full?`<td>${safe(r.ref)}</td>`:''}<td>${safe(r.date)}</td><td>${status(r.status)}</td></tr>`}
function renderTables(){ $('recentTable').innerHTML=requests.slice(0,4).map(r=>row(r)).join('');const q=($('requestSearch')?.value||'').toLowerCase();const st=$('statusFilter')?.value||'all';const list=requests.filter(r=>(r.id+' '+r.service+' '+r.ref).toLowerCase().includes(q)&&(st==='all'||r.status===st));$('requestsTable').innerHTML=list.length?list.map(r=>row(r,true)).join(''):'<tr><td class="empty-row" colspan="5">No matching requests.</td></tr>';$('totalRequests').textContent=12+Math.max(0,requests.length-5);$('pendingRequests').textContent=3+requests.filter(r=>r.status==='Pending'&&r.id.startsWith('MBK-NEW')).length}
function navigate(page){document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+page));document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.page===page));$('breadcrumbPage').textContent=({overview:'Overview',services:'All Services',requests:'Request History',account:'Account & Settings'})[page]||'Overview';$('sidebar').classList.remove('open');window.scrollTo({top:0,behavior:'smooth'})}
function toast(message){const el=$('toast');el.textContent=message;el.classList.add('show');clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>el.classList.remove('show'),3200)}
function openModal(key){const s=services.find(x=>x.key===key);if(!s)return;$('selectedService').value=s.key;$('modalTitle').textContent=s.name;$('modalDescription').textContent=s.desc;$('modalSymbol').textContent=s.icon;$('referenceInput').value='';$('noteInput').value='';$('requestModal').classList.add('open');setTimeout(()=>$('referenceInput').focus(),50)}
function closeModal(){$('requestModal').classList.remove('open')}
document.addEventListener('click',e=>{const nav=e.target.closest('[data-page]');if(nav)navigate(nav.dataset.page);const go=e.target.closest('[data-goto]');if(go)navigate(go.dataset.goto);const svc=e.target.closest('[data-service]');if(svc)openModal(svc.dataset.service)});
$('serviceSearch').addEventListener('input',renderServices);$('requestSearch').addEventListener('input',renderTables);$('statusFilter').addEventListener('change',renderTables);
$('menuToggle').addEventListener('click',()=>$('sidebar').classList.toggle('open'));
$('dismissNotice').addEventListener('click',()=>document.querySelector('.notice').remove());
$('notifyBtn').addEventListener('click',()=>toast('No new notifications in this demo.'));
$('signOut').addEventListener('click',()=>toast('Demo mode has no signed-in account to sign out.'));
$('modalClose').addEventListener('click',closeModal);$('cancelModal').addEventListener('click',closeModal);
$('requestModal').addEventListener('click',e=>{if(e.target===$('requestModal'))closeModal()});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal()});
$('demoForm').addEventListener('submit',e=>{e.preventDefault();const s=services.find(x=>x.key===$('selectedService').value);const ref=$('referenceInput').value.trim();if(!ref)return;const id='MBK-NEW'+String(Date.now()).slice(-5);requests.unshift({id,service:s.name,ref:ref.length>5?'•••• '+ref.slice(-4):ref,date:new Date().toLocaleDateString('en-GB',{day:'2-digit',month:'short',year:'numeric'}),status:'Pending'});closeModal();renderTables();navigate('requests');toast('Demo request created locally. No provider API was called.');});
renderServices();renderTables();
